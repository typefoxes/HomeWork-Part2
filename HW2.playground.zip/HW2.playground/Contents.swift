import UIKit

// 4. Напишите, для чего нужны дженерики.
// Дженерики позволяют написать код в универсальной форме, без ограничений с типами.

// 5. Укажите, чем ассоциированные типы отличаются от дженериков.
// Ассоциированные типы это аналог дженериков. только на уровне протоколов


//6. Создайте функцию, которая:

    //6.a) получает на вход два Equatable-объекта и, в зависимости от того, равны ли они друг другу, выводит разные сообщения в лог;
    
    func taskA<T: Equatable>(a: T, b: T) {
        if a == b {
            print("\(a) равен \(b)")
        } else {
            print("\(a) не равен \(b)")
        }
    }
taskA(a: "А", b: "Б")
    print("А" == "Б")
    
   //  6.b) получает на вход два сравниваемых (Comparable) друг с другом значения, сравнивает их и выводит в лог наибольшее;

func taskB(a: Int, b: Int) -> Int  { a > b ? a : b }
taskB(a: 125, b: 234)
print(max(125, 234))

// 6.c. получает на вход два сравниваемых (Comparable) друг с другом значения, сравнивает их и перезаписывает первый входной параметр меньшим из двух значений, а второй параметр – большим
func taskC<T: Comparable>(a: T, b: T) {
    let ex1 = min(a, b)
    let ex2 = max(a, b)
    print(ex1,ex2)
}
taskC(a: 999, b: 111)

func swapTwo<T>(_ a: inout T, _ b: inout T) {
    let temp = a
    a = b
    b = temp
}

// 6.d) получает на вход две функции, которые имеют дженерик — входной параметр Т и ничего не возвращают; сама функция должна вернуть новую функцию, которая на вход получает параметр с типом Т и при своём вызове вызывает две функции и передаёт в них полученное значение (по факту объединяет две функции).

func taskD<T>(first: @escaping(_ part1: T) -> (), second: @escaping(_ part2: T) -> ()) -> (T) -> () {
    let returnFunc: (T) -> () = { tValue in
        first(tValue)
        second(tValue)
    }
    return returnFunc
}

taskD(first: { (T) in
    return T
}, second: { (T) in
    return T
})
// 7. Создайте расширение для:

// 7.a) Array, у которого элементы имеют тип Comparable, и добавьте генерируемое свойство, которое возвращает максимальный элемент;
extension Array where Element: Comparable {
    func maxi() -> Element? {
        guard let first = first else { return nil }
        return reduce(first, Swift.max)
    }
}
var IntArray = [1,6,2,4,8,33,0,2000,100,100]

IntArray.maxi()

// 7.b) Array, у которого элементы имеют тип Equatable, и добавьте функцию, которая удаляет из массива идентичные элементы.

extension Array where Element: Equatable {
    func dupl() -> [Element] {
        var result = [Element]()
        for el in self {
            if result.contains(el) == false {
                result.append(el)
            }
        }
        return result
    }
    func dupl2() -> [Element] {
        var test1 = [Element]()
        var test2 = [Element]()
        for el in self {
            if test1.contains(el) == false {
                test1.append(el)
            } else {
                test2.append(el)
            }
        }
        return test1.filter { return !test2.contains($0) }
    }
}

IntArray
IntArray.dupl() // MARK: удалит дубликат 100
IntArray.dupl2() // MARK: так 100 совсем нет

//8. Создайте специальный оператор для:

//     8.a) возведения Int-числа в степень: оператор ^^, работает 2^3, возвращает 8;
infix operator ^^
func ^^(a: Int, b: Int) -> Int {
    Array(repeating: a, count: Int(b)).reduce(1, *)
}
2^^3
pow(2, 3)

// 8.b. Создайте специальный оператор для копирования во второе Int число удвоенное значение первого 4 ~> a после этого a = 8
postfix operator ~>
postfix func ~> (a: Int) -> [Int] {
    [a,a*2]
}
4~>
// 8.c. Создайте специальный оператор для присваивания в экземпляр tableView делегата: myController <* tableView поле этого myController становится делегатом для tableView
infix operator <*
func <*(myController: UIViewController, tableView: UITableView) {
    var a: Void = myController.viewDidLoad()
    a = {
        tableView.delegate
        tableView.dataSource
    }()
    a.self
}

let vc1 = UIViewController()
let tv1 = UITableView()

vc1 <* tv1

// 8.d. Создайте специальный оператор для суммирует описание двух объектов с типом CustomStringConvertable и возвращает их описание: 7 + “ string” вернет “7 string”
struct Task8d {
    let number: Int
    let sring: String
}
extension Task8d: CustomStringConvertible {
    var description: String {
        return "\(number)" + " \(sring)"
    }
}
let task8d = Task8d(number: 7, sring: "string")

// 9. Напишите для библиотеки анимаций новый аниматор:

// 9.b. изменяющий center UIView
protocol Center {
    associatedtype Target
    func CenterChange(t: Target)
}

// 9.c. делающий scale трансформацию для UIView
protocol Scale {
    associatedtype Target
    func scaleAnimator(t: Target)
}

// 9.a) изменяющий фоновый цвет для UIView;

let view = UIView()

view.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
protocol BC {
    associatedtype Target
    func backAnimator(t: Target)
}
class ViewClass: BC, Center, Scale {
    func scaleAnimator(t: UIView) {
        UIView.animate(withDuration: 1.0, delay: 0, options: [.repeat,.autoreverse], animations: {
            view.transform = CGAffineTransform(scaleX: 2, y: 2)
        })
    }
    
    func CenterChange(t: UIView) {
        view.center = CGPoint(x: 100, y: 100)
    }
    
    func backAnimator(t: UIView) {
        UIView.animate(withDuration: 1.0, delay: 0, options: [.repeat,.autoreverse], animations: {
            t.backgroundColor = .systemRed; t.backgroundColor = .systemBlue
        })
    }
}
ViewClass().backAnimator(t: view)
ViewClass().CenterChange(t: view)
ViewClass().scaleAnimator(t: view)

